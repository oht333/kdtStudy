package ex05_오현택;

public class Main {
//	1)Zoo객체를 만들기
//	2)객체명.메소드명()으로 호출해서 모든 동물의 행동 출력
	Zoo zoo = new Zoo(null);
}
