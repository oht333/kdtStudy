package ex06_오현택;

public interface Account {
	//1) 메소드 선언(구현부는 적지 말아야함)
	int getBalance();
	void printDetails();
}
