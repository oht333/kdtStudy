package task1;

public class EmployeeService {
	//아이디를 인수로 사원정보 출력하는 메소드
	
	
	//모든 사원의 종보출력 메소드?(entrySet 사용)
	
	
	
	//salary 3000추가하는 메소드
	int addSalary(int salary) {
		return salary += 3000;
	}
	
	
}
